﻿using UnityEngine;
using System.Collections;

public class NextLevel : MonoBehaviour {

	void OnTriggerEnter(Collider other) {
		Application.LoadLevel(Application.loadedLevel +1);
	}
}
