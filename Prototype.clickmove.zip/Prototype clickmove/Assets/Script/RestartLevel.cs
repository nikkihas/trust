﻿using UnityEngine;
using System.Collections;

public class RestartLevel : MonoBehaviour {

	void OnTriggerEnter(Collider other) {
		Application.LoadLevel(Application.loadedLevel);
	}
}
