﻿using UnityEngine;
using System.Collections;

public class ThirdPersonController : MonoBehaviour
{

	static public float movementSpeed = 5.0f;
	public float turnSensitivity = 2.0f;

	// Use this for initialization
	void Start ()
	{
		//Screen.lockCursor = true;
	}

	// Update is called once per frame
	void Update ()
	{
		//rotation

		float rotLeftRight = Input.GetAxis ("Horizontal") * turnSensitivity;
		transform.Rotate (0, rotLeftRight, 0);

		//movement
		float forwardSpeed = Input.GetAxis ("Vertical") * movementSpeed;

		Vector3 speed = new Vector3 (0, 0, forwardSpeed);

		speed = transform.rotation * speed;

		CharacterController cc = GetComponent<CharacterController> ();

		cc.SimpleMove (speed);
	}
}
